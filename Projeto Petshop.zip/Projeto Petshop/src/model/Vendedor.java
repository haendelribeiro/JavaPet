package model;

public class Vendedor extends Funcionario{
}
