package model;

public class Recepicionista extends Funcionario{
}
