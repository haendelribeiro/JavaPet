package model;

public class Tosador extends Funcionario{

}
