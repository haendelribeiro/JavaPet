package model;

public class Pet {
}
