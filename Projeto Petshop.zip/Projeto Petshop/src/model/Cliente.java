package model;

public abstract class Cliente {
}
