package model;

public class Medico extends Funcionario{

    public Medico(String nome, char sexo, int idade, double salario) {
        super(nome, sexo, idade, salario);
    }
}
